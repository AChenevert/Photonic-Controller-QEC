%% Same syndrome, different recovery: a concrete teaching example.
% The example explicitly uses p_bad = 0.10. It is not the default experiment.
[exampleResult,code] = exact_surface_code_monitor(struct('p_bad',0.10));
errorA = zeros(1,9); errorA(1)=1;
errorB = zeros(1,9); errorB([4 7])=1;
fprintf('Stronger-anomaly illustration: p_bad = 0.10\n');
fprintf('A: X on qubit 1. Syndrome: %s. Class: %d.\n', ...
    mat2str(mod(errorA*code.HZ',2)),mod(errorA*code.LZ',2));
fprintf('B: X on qubits 4 and 7. Syndrome: %s. Class: %d.\n', ...
    mat2str(mod(errorB*code.HZ',2)),mod(errorB*code.LZ',2));

% Decoder inputs: the observed syndrome and, optionally, these alarms.
monitor = zeros(1,9); monitor([4 7])=1;
probabilities = monitor*code.p_alarm+(1-monitor)*code.p_quiet;
weights = prod(code.errors.*probabilities+(1-code.errors).*(1-probabilities),2);
monitorJoint = reshape(accumarray(code.joint_index,weights,[32 1]),16,2)';
syndromeID = 4; % Bits [0 0 1 0], first check the least significant bit.
tables = {code.prior_joint,monitorJoint};
names = {'Syndrome only','Syndrome plus alarms on qubits 4 and 7'};
for decoder = 1:2
    mass = tables{decoder}(:,syndromeID+1);
    posterior = mass/sum(mass);
    [~,row] = max(mass); chosenClass = row-1;
    candidates = code.errors(code.syndrome_id==syndromeID ...
        & code.logical_class==chosenClass,:);
    [~,lightest] = min(sum(candidates,2));
    recovery = candidates(lightest,:);
    fprintf('\n%s\n',names{decoder});
    fprintf('  Class 0 probability: %.6f; class 1 probability: %.6f.\n',posterior);
    fprintf('  Choose class %d; apply X on qubits %s.\n',chosenClass,mat2str(find(recovery)));
end
fprintf('\nClass masses sum all 16 equivalent words, not only A and B.\n');
fprintf('The monitor changes the best guess; it does not reveal the actual fault.\n');
