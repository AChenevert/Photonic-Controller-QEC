Monitor-Assisted Quantum Error Correction in MATLAB

This teaching example asks whether noisy information about control-channel risk can help a surface-code decoder choose a better recovery.

The syndrome reports collective quantum checks. The monitor supplies extra information about which control channels have a higher fault probability. It does not add stabilizer checks or identify actual faults.

Start with Monitor_Assisted_QEC_MATLAB_Guide.pdf or the equivalent plain text file. All code comments and explanations are in English.

Use MATLAB R2020b or newer with base MATLAB. No extra toolbox or Python installation is required. Set this folder as MATLAB's Current Folder, then enter these commands one at a time:

run_demo
show_example
run_validation
plot_results

The last command is optional. Edit the five teaching parameters in run_demo.m one at a time, or call the function directly:

result = exact_surface_code_monitor();
result = exact_surface_code_monitor(struct('p_bad', 0.10));

The model uses nine data qubits, one independent X-error layer, and perfect syndrome measurements. It enumerates every error and monitor word and sums probabilities over stabilizer-equivalent logical classes. Both decoders face the same physical error distribution. There are no sampled shots or discarded trials.

The default reference logical failure probabilities are 0.0002113845683 for syndrome only and 0.0002099323731 with the noisy monitor. This is a 0.687% relative reduction. With p_bad = 0.10, the corresponding values are 0.0006226238870 and 0.0004820882069, a 22.57% relative reduction under worse physical noise. These are illustrative mathematical reference results, not hardware measurements.

run_demo.m sets parameters and writes JSON and CSV results. exact_surface_code_monitor.m contains the probability model and decoder. show_example.m illustrates two errors with the same syndrome. run_validation.m checks recovery classes, reference values, controls, numeric input types and an independent joint calculation. plot_results.m creates the optional MATLAB comparison figure. The JSON files named python_reference contain the independently checked mathematical reference values.

All valid numeric parameters are converted to double before probability arithmetic. A single-precision input keeps its already rounded value when converted; it need not equal a separately written double literal.

MATLAB execution has not been verified in this environment because the installed runtime could not start. The mathematical reference was checked in Python, and the revised MATLAB files passed static Code Analyzer checks. Run run_validation locally before reporting reproduced MATLAB results. See REVIEW_STATUS.txt for details.

This starter does not model optical hardware, noisy check circuits, multiple rounds, coherent or correlated noise, measured monitor calibration, or real-time deadlines.
