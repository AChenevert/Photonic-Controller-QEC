function run_validation()
% RUN_VALIDATION Verify the MATLAB decoder and save every scan point.
% Uses base MATLAB only. No Statistics, Quantum Computing, or other toolbox.
[reference,code] = exact_surface_code_monitor();
tol = 1e-12;

%% 1. Recovery must clear the syndrome AND preserve the logical information.
generators = zeros(16,4);
for column=1:4, generators(:,column)=bitget((0:15)',column); end
stabilizers = mod(generators*code.HX,2);
assert(size(unique(stabilizers,'rows'),1)==16);
for errorIndex=1:512
    actual = code.errors(errorIndex,:);
    syndrome = code.syndrome_id(errorIndex);
    for chosenClass=0:1
        candidates = code.errors(code.syndrome_id==syndrome ...
            & code.logical_class==chosenClass,:);
        [~,index] = min(sum(candidates,2));
        recovery = candidates(index,:);
        residual = mod(actual+recovery,2);
        assert(~any(mod(residual*code.HZ',2)),'Recovery left a syndrome.');
        assert(ismember(residual,stabilizers,'rows') ...
            == (chosenClass==code.logical_class(errorIndex)), ...
            'Logical success disagrees with stabilizer membership.');
    end
end
singleErrors = eye(9);
singleSyndromes = mod(singleErrors*code.HZ',2)*(2.^(0:3))';
singleDecisions = code.baseline_decision(singleSyndromes+1);
assert(all(singleDecisions(:)==mod(singleErrors*code.LZ',2)), ...
    'A single X error was not corrected.');

%% 2. Regression against the independently reviewed Python calculation.
assert(abs(reference.baseline_ler-0.00021138456831666823)<tol);
assert(abs(reference.monitor_ler-0.0002099323730658157)<tol);
assert(abs(reference.shuffled_monitor_ler-0.00021649800308700214)<tol);
assert(abs(reference.perfect_risk_monitor_ler-0.0001538930539115118)<tol);
stronger = exact_surface_code_monitor(struct('p_bad',0.10));
assert(abs(stronger.baseline_ler-0.000622623886978252)<tol);
assert(abs(stronger.monitor_ler-0.00048208820689424017)<tol);

%% 3. Negative controls and sensor boundary cases.
zero = exact_surface_code_monitor(struct('p_good',0,'p_bad',0));
assert(zero.baseline_ler==0 && zero.monitor_ler==0);
controlSettings = {struct('p_good',0.02,'p_bad',0.02), ...
    struct('bad_fraction',0),struct('bad_fraction',1), ...
    struct('false_positive',0.5,'false_negative',0.5), ...
    struct('false_positive',0.2,'false_negative',0.8), ...
    struct('false_positive',0,'false_negative',1), ...
    struct('false_positive',1,'false_negative',0)};
for setting=1:numel(controlSettings)
    r = exact_surface_code_monitor(controlSettings{setting});
    assert(abs(r.monitor_ler-r.baseline_ler)<tol,'No-information control failed.');
end
inverted = exact_surface_code_monitor(struct('false_positive',1,'false_negative',1));
assert(abs(inverted.monitor_ler-reference.perfect_risk_monitor_ler)<tol);

%% 4. Invalid settings must produce a clear input error.
names = fieldnames(reference.parameters);
badValues = {NaN,Inf,-0.01,1.01,[0.01 0.02],'not a probability'};
for name=1:numel(names)
    for value=1:numel(badValues)
        invalid = struct(); invalid.(names{name})=badValues{value};
        expect_input_error(invalid);
    end
end
expect_input_error(struct('p_good',0.10,'p_bad',0.05));
expect_input_error(struct('p_bad',0.50));
expect_input_error(struct('misspelled_parameter',0.1));

% Valid numeric types must use double-precision probability arithmetic.
typedSettings = {struct('bad_fraction',uint8(1),'false_positive',uint8(0)), ...
    struct('p_bad',single(0.10),'false_negative',single(0.20))};
for setting=1:numel(typedSettings)
    typed = typedSettings{setting};
    converted = typed;
    typedNames = fieldnames(typed);
    for field=1:numel(typedNames)
        converted.(typedNames{field}) = double(typed.(typedNames{field}));
    end
    typedResult = exact_surface_code_monitor(typed);
    doubleResult = exact_surface_code_monitor(converted);
    for field=1:numel(names)
        assert(isa(typedResult.parameters.(names{field}),'double'), ...
            'A validated parameter was not converted to double.');
    end
    checkedFields = {'baseline_ler','monitor_ler','shuffled_monitor_ler', ...
        'perfect_risk_monitor_ler','uninformative_monitor_ler', ...
        'fault_probability_if_alarm','fault_probability_if_no_alarm'};
    for field=1:numel(checkedFields)
        assert(abs(typedResult.(checkedFields{field}) ...
            - doubleResult.(checkedFields{field}))<tol, ...
            'Numeric input types changed the calculation.');
    end
end

%% 5. Independent full P(error,monitor) enumeration, without Bayes formulas.
directDefault = independent_joint_check(reference.parameters,code);
asymmetricParameters = struct('bad_fraction',0.13,'p_good',0.003,'p_bad',0.12, ...
    'false_positive',0.07,'false_negative',0.35);
directAsymmetric = independent_joint_check(asymmetricParameters,code);

%% 6. Preserve all twelve scan points, including small or zero benefits.
scans = cell(1,12); index=0;
for pBad=[0.02 0.05 0.10 0.20]
    for falsePositive=[0.001 0.005 0.02]
        index=index+1;
        scans{index}=exact_surface_code_monitor(struct('p_bad',pBad, ...
            'false_positive',falsePositive));
    end
end
report = struct('checks','all passed','matlab_version',version, ...
    'matlab_release',version('-release'),'scope',reference.scope, ...
    'independent_default',directDefault,'independent_asymmetric',directAsymmetric, ...
    'scan_definition',struct('p_bad',[0.02 0.05 0.10 0.20], ...
    'false_positive',[0.001 0.005 0.02],'false_negative',0.20, ...
    'bad_fraction',0.05,'p_good',0.001),'all_scan_results',{scans});
outputFolder=fullfile(fileparts(mfilename('fullpath')),'results');
if ~exist(outputFolder,'dir'),mkdir(outputFolder);end
file=fopen(fullfile(outputFolder,'validation_and_scan.json'),'w');
assert(file>=0,'Could not open the validation report.');
fprintf(file,'%s\n',jsonencode(report));fclose(file);
fprintf('All six validation sections and all twelve scan points passed.\n');
fprintf('Checked all 512 errors and both recovery classes.\n');
fprintf('Saved results/validation_and_scan.json.\n');
end

function expect_input_error(parameters)
caught=false;
try
    exact_surface_code_monitor(parameters);
catch exception
    caught=strcmp(exception.identifier,'monitorQEC:InvalidInput');
    if ~caught,rethrow(exception);end
end
assert(caught,'Invalid input was accepted.');
end

function direct=independent_joint_check(p,code)
% Sum latent good/bad contributions for each local (fault,alarm) outcome.
siteJoint=zeros(2,2);
states=[1-p.bad_fraction,p.p_good,p.false_positive; ...
    p.bad_fraction,p.p_bad,1-p.false_negative];
for errorBit=0:1
    for alarm=0:1
        for state=1:2
            pe=states(state,2);pm=states(state,3);
            if errorBit==0,pe=1-pe;end
            if alarm==0,pm=1-pm;end
            siteJoint(errorBit+1,alarm+1)=siteJoint(errorBit+1,alarm+1) ...
                + states(state,1)*pe*pm;
        end
    end
end
fullJoint=ones(512,512);
for qubit=1:9
    fullJoint=fullJoint.*siteJoint(code.errors(:,qubit)+1,code.monitors(:,qubit)+1);
end
assert(abs(sum(fullJoint,'all')-1)<1e-12,'Latent joint table is not normalized.');
classes=zeros(2,16,512);
for logicalClass=0:1
    for syndrome=0:15
        mask=code.logical_class==logicalClass & code.syndrome_id==syndrome;
        classes(logicalClass+1,syndrome+1,:)=reshape(sum(fullJoint(mask,:),1),1,1,512);
    end
end
prior=sum(classes,3);
baseline=sum(min(prior,[],1));
monitored=sum(min(classes,[],1),'all');
monitorMass=sum(fullJoint,1);
independent=0;
for word=1:512
    [~,chosen]=max(classes(:,:,word),[],1);
    wrong=sub2ind([2,16],3-chosen,1:16);
    independent=independent+monitorMass(word)*sum(prior(wrong));
end
r=exact_surface_code_monitor(p);
assert(abs(baseline-r.baseline_ler)<1e-12,'Independent baseline disagrees.');
assert(abs(monitored-r.monitor_ler)<1e-12,'Independent monitor result disagrees.');
assert(abs(independent-r.shuffled_monitor_ler)<1e-12,'Independent shuffle control disagrees.');
direct=struct('total_probability',sum(fullJoint,'all'), ...
    'baseline_ler',baseline,'monitor_ler',monitored,'shuffled_monitor_ler',independent);
end
