function [result, model] = exact_surface_code_monitor(parameters)
% EXACT_SURFACE_CODE_MONITOR Can noisy control-risk information help QEC?
%   result = exact_surface_code_monitor() runs the default example.
%   result = exact_surface_code_monitor(struct('p_bad', 0.10)) changes one setting.
%   [result, model] also returns the code arrays for teaching and validation.
%
%   Scope: nine data qubits, one independent X-error layer, perfect checks.
%   All error and monitor patterns are enumerated. No shots are discarded.
%   The monitor observes control risk, never the realized X error.
%   Requires base MATLAB only. Read the English PDF before extending the model.

if nargin == 0, parameters = struct(); end
parameters = complete_parameters(parameters);
model = build_code();

% The baseline knows the correct average error probability at every qubit.
pAverage = (1-parameters.bad_fraction)*parameters.p_good ...
    + parameters.bad_fraction*parameters.p_bad;
priorJoint = joint_probabilities(repmat(pAverage,1,9),model);
[~,baselineRow] = max(priorJoint,[],1); % MATLAB row 1 = class 0; row 2 = class 1.
wrongClassIndex = sub2ind([2,16],3-baselineRow,1:16);
baseline = sum(priorJoint(wrongClassIndex));

sensor = evaluate_sensor(parameters,model,priorJoint,baselineRow);
perfectParameters = parameters;
perfectParameters.false_positive = 0;
perfectParameters.false_negative = 0;
perfect = evaluate_sensor(perfectParameters,model,priorJoint,baselineRow);
uninformativeParameters = parameters;
uninformativeParameters.false_positive = 0.5;
uninformativeParameters.false_negative = 0.5;
uninformative = evaluate_sensor(uninformativeParameters,model,priorJoint,baselineRow);

% These checks remain active in MATLAB. They protect the fair comparison.
tol = 1e-12;
assert(sensor.monitor_ler <= baseline+tol,'Matched optimal decoding cannot get worse.');
assert(perfect.monitor_ler <= sensor.monitor_ler+tol,'Perfect risk must be at least as informative.');
assert(abs(uninformative.monitor_ler-baseline)<tol,'Uninformative monitor must give no benefit.');
assert(sensor.shuffled_monitor_ler >= baseline-tol,'Independent records cannot beat the optimal baseline.');

result = struct();
result.scope = 'd=3 rotated surface code; X-only data noise; perfect checks; one layer';
result.method = 'Exact probability sums; optimal logical-class decoding; no postselection';
result.parameters = parameters;
result.average_physical_X_probability = pAverage;
result.baseline_ler = baseline;
result.monitor_ler = sensor.monitor_ler;
result.shuffled_monitor_ler = sensor.shuffled_monitor_ler;
result.perfect_risk_monitor_ler = perfect.monitor_ler;
result.uninformative_monitor_ler = uninformative.monitor_ler;
result.fault_probability_if_alarm = sensor.p_alarm;
result.fault_probability_if_no_alarm = sensor.p_quiet;
result.relative_reduction = 0;
if baseline > 0
    result.relative_reduction = 1-sensor.monitor_ler/baseline;
end
result.all_builtin_checks_passed = true;
result.matlab_version = version;
result.matlab_release = version('-release');

% These teaching arrays are not extra observations supplied to the decoder.
model.prior_joint = priorJoint;
model.baseline_decision = baselineRow-1;
model.alarm_probability = sensor.alarm_probability;
model.p_alarm = sensor.p_alarm;
model.p_quiet = sensor.p_quiet;
end

function p = complete_parameters(overrides)
% Named settings make one-variable student experiments easy to read.
p = struct('bad_fraction',0.05,'p_good',0.001,'p_bad',0.05, ...
    'false_positive',0.02,'false_negative',0.20);
if ~isstruct(overrides) || ~isscalar(overrides)
    error('monitorQEC:InvalidInput','Parameters must be a scalar struct.');
end
names = fieldnames(overrides);
for k = 1:numel(names)
    name = names{k};
    if ~isfield(p,name)
        error('monitorQEC:InvalidInput','Unknown parameter: %s',name);
    end
    p.(name) = overrides.(name);
end
names = fieldnames(p);
for k = 1:numel(names)
    value = p.(names{k});
    if ~isnumeric(value) || ~isreal(value) || ~isscalar(value) ...
            || ~isfinite(value) || value<0 || value>1
        error('monitorQEC:InvalidInput','%s must be a finite probability in [0,1].',names{k});
    end
    % Use one arithmetic type even when a caller supplies single or integer data.
    p.(names{k}) = double(value);
end
if p.p_good>p.p_bad || p.p_bad>=0.5
    error('monitorQEC:InvalidInput','Require 0 <= p_good <= p_bad < 0.5.');
end
end

function code = build_code()
% MATLAB numbering: top row 1,2,3; middle row 4,5,6; bottom row 7,8,9.
code.HX = check_matrix({[1 2 4 5],[5 6 8 9],[2 3],[7 8]});
code.HZ = check_matrix({[2 3 5 6],[4 5 7 8],[1 4],[6 9]});
code.LZ = [1 1 1 0 0 0 0 0 0];
code.LX = [1 0 0 1 0 0 1 0 0];
code.errors = binary_words(9);
code.monitors = binary_words(9);
code.syndrome_bits = mod(code.errors*code.HZ',2);
code.syndrome_id = code.syndrome_bits*(2.^(0:3))'; % IDs 0 through 15.
code.logical_class = mod(code.errors*code.LZ',2); % Classes 0 and 1.
code.joint_index = 1+code.syndrome_id+16*code.logical_class;

assert(~any(mod(code.HX*code.HZ',2),'all'),'X and Z checks must commute.');
assert(~any(mod(code.HX*code.LZ',2)),'Logical Z must commute with X checks.');
assert(~any(mod(code.HZ*code.LX',2)),'Logical X must commute with Z checks.');
assert(mod(code.LX*code.LZ',2)==1,'Logical X and Z must anticommute.');
for kind = 1:2
    if kind==1, checks=code.HZ; opposite=code.LZ;
    else, checks=code.HX; opposite=code.LX; end
    group = mod(binary_words(4)*checks,2);
    assert(size(unique(group,'rows'),1)==16,'Four checks must be independent.');
    nontrivial = all(mod(code.errors*checks',2)==0,2) ...
        & mod(code.errors*opposite',2)==1;
    assert(min(sum(code.errors(nontrivial,:),2))==3,'Code distance must be three.');
end
counts = accumarray(code.joint_index,1,[32,1]);
assert(all(counts==16),'Every syndrome/class must contain 16 equivalent errors.');
end

function words = binary_words(n)
% Column i corresponds to qubit/check i, with column 1 the least significant bit.
words = zeros(2^n,n);
for column = 1:n
    words(:,column) = bitget((0:2^n-1)',column);
end
end

function matrix = check_matrix(supports)
matrix = zeros(numel(supports),9);
for row = 1:numel(supports)
    matrix(row,supports{row}) = 1;
end
end

function joint = joint_probabilities(p,code)
% Add all stabilizer-equivalent words, rather than choosing one error word.
weights = prod(code.errors.*p+(1-code.errors).*(1-p),2);
masses = accumarray(code.joint_index,weights,[32,1]);
joint = reshape(masses,16,2)'; % Rows: class 0/1; columns: syndrome ID + 1.
assert(abs(sum(joint,'all')-1)<1e-12,'Error probabilities must sum to one.');
end

function sensor = evaluate_sensor(p,code,priorJoint,baselineRow)
% Bayes update: an alarm estimates risk, then risk estimates fault probability.
rho = p.bad_fraction;
pm1 = rho*(1-p.false_negative)+(1-rho)*p.false_positive;
if pm1>0, riskAlarm=rho*(1-p.false_negative)/pm1; else, riskAlarm=rho; end
if pm1<1, riskQuiet=rho*p.false_negative/(1-pm1); else, riskQuiet=rho; end
pAlarm = p.p_good+(p.p_bad-p.p_good)*riskAlarm;
pQuiet = p.p_good+(p.p_bad-p.p_good)*riskQuiet;
monitorMass = prod(code.monitors*pm1+(1-code.monitors)*(1-pm1),2);

conditioned = 0; independent = 0; baselineRecomputed = 0;
reconstructed = zeros(2,16);
baselineWrong = sub2ind([2,16],3-baselineRow,1:16);
for word = 1:size(code.monitors,1)
    pm = monitorMass(word);
    if pm==0, continue; end % Impossible observations have zero weight.
    monitor = code.monitors(word,:);
    probabilities = monitor*pAlarm+(1-monitor)*pQuiet;
    joint = joint_probabilities(probabilities,code);
    [~,chosenRow] = max(joint,[],1); % Exact ties choose the first row (class 0).
    wrong = sub2ind([2,16],3-chosenRow,1:16);
    conditioned = conditioned+pm*sum(joint(wrong));
    % Independent records preserve alarm statistics but lose error association.
    independent = independent+pm*sum(priorJoint(wrong));
    baselineRecomputed = baselineRecomputed+pm*sum(joint(baselineWrong));
    reconstructed = reconstructed+pm*joint;
end
assert(max(abs(reconstructed-priorJoint),[],'all')<1e-12, ...
    'Conditioning must recover the original physical distribution.');
assert(abs(baselineRecomputed-sum(priorJoint(baselineWrong)))<1e-12, ...
    'Both decoders must score the same physical distribution.');
sensor = struct('monitor_ler',conditioned,'shuffled_monitor_ler',independent, ...
    'alarm_probability',pm1,'p_alarm',pAlarm,'p_quiet',pQuiet);
end
