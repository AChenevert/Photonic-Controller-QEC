%% Monitor-assisted surface-code decoding: start here.
% Run this script from its folder. Change one parameter at a time.
% All parameters below are teaching assumptions, not measured device values.

parameters = struct();
parameters.bad_fraction = 0.05;
parameters.p_good = 0.001;
parameters.p_bad = 0.05;          % Try 0.10 for the stronger-anomaly example.
parameters.false_positive = 0.02;
parameters.false_negative = 0.20;

result = exact_surface_code_monitor(parameters);
Decoder = {'Syndrome only';'Syndrome + noisy monitor';'Independent monitor'; ...
    'Perfect risk monitor';'Uninformative monitor'};
LogicalFailureProbability = [result.baseline_ler;result.monitor_ler; ...
    result.shuffled_monitor_ler;result.perfect_risk_monitor_ler; ...
    result.uninformative_monitor_ler];
comparison = table(Decoder,LogicalFailureProbability);
disp(comparison);
fprintf('Relative reduction: %.4f %%\n',100*result.relative_reduction);
fprintf('Exact one-layer probabilities, not sampled shots or hardware results.\n');

outputFolder = fullfile(fileparts(mfilename('fullpath')),'results');
if ~exist(outputFolder,'dir'), mkdir(outputFolder); end
file = fopen(fullfile(outputFolder,'exact_results.json'),'w');
assert(file>=0,'Could not open the results file.');
fprintf(file,'%s\n',jsonencode(result));
fclose(file);
writetable(comparison,fullfile(outputFolder,'decoder_comparison.csv'));
fprintf('Saved JSON and CSV in the results folder.\n');
