function plot_results()
% PLOT_RESULTS Optional comparison figure, using base MATLAB only.
% The displayed counts are expectations, not one million simulated shots.
outputFolder=fullfile(fileparts(mfilename('fullpath')),'results');
if ~exist(outputFolder,'dir'),mkdir(outputFolder);end
cases={exact_surface_code_monitor(),exact_surface_code_monitor(struct('p_bad',0.10))};
names={'Syndrome only','Noisy monitor','Independent record','Perfect risk','Uninformative'};
fig=figure('Visible','off','Color','white','Position',[100 100 1200 460]);
tiledlayout(1,2,'TileSpacing','compact','Padding','compact');
for example=1:2
    r=cases{example};
    values=1e6*[r.baseline_ler,r.monitor_ler,r.shuffled_monitor_ler, ...
        r.perfect_risk_monitor_ler,r.uninformative_monitor_ler];
    nexttile;bar(values);xticks(1:5);xticklabels(names);xtickangle(25);
    ylim([0 1200]);grid on;
    ylabel('Expected logical failures per 1,000,000 experiments');
    title(sprintf('p_{bad} = %.2f; reduction = %.2f%%',r.parameters.p_bad,100*r.relative_reduction));
    for item=1:5,text(item,values(item)+20,sprintf('%.1f',values(item)), ...
            'HorizontalAlignment','center');end
end
sgtitle('Exact one-layer X-error model with perfect checks');
exportgraphics(fig,fullfile(outputFolder,'matlab_decoder_comparison.png'),'Resolution',180);
close(fig);
fprintf('Saved results/matlab_decoder_comparison.png.\n');
end
